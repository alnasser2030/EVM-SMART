TPEC 2027 - two papers, LaTeX sources (IEEE conference format, IEEEtran)

paper1_EEF_model/   External Energy Flexibility: model, 90% target, size range, scale to 6 GW and the Saudi grid (6 pages)
  eef_tpec2027.tex        main file
  refs.bib, refs_extra.bib, eef_tpec2027.bbl
  figures/                fig1_architecture, fig3_cfe_vs_flex, fig4_target_size, fig5_monthly (PDF)
  eef_tpec2027.pdf        compiled paper

paper2_review/      Review of internal and external flexibility (6 pages)
  eef_review_tpec2027.tex main file (Figs. 1, 4 and 5 are TikZ inside the .tex)
  refs.bib, eef_review_tpec2027.bbl
  figures/                fig_years, fig_mismatch (PDF)
  eef_review_tpec2027.pdf compiled paper

Compile (each folder on its own):
  pdflatex <main> ; bibtex <main> ; pdflatex <main> ; pdflatex <main>
Overleaf: upload one folder as a new project, set the main .tex as the main document, compiler pdfLaTeX.

Authors: Ali Awad Ali Nasser and Mehrdad Ehsani, Department of Electrical and Computer Engineering, Texas A&M University.
The figure scripts (figures/*.py) are included for reference; they read the model results in the
EVM-SMART repository (tpec2027/results, docs/thesis/refs.bib) and are not needed to compile.
